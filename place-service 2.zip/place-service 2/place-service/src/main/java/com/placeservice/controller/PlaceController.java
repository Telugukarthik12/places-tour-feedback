package com.placeservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.placeservice.dto.PlaceDTO;
import com.placeservice.service.PlaceService;

import jakarta.validation.Valid;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("place")
public class PlaceController {

    private static final Logger logger = LoggerFactory.getLogger(PlaceController.class);

    @Autowired
    public PlaceService placeservice;

    @Valid
    @PostMapping("/addplace")
    public ResponseEntity<String> addPlace(@RequestBody PlaceDTO placeDto) {
        logger.info("Received request to add place: {}", placeDto.getPlaceName());
        return placeservice.addPlace(placeDto);
    }

    @GetMapping("/getallplaces")
    public ResponseEntity<List<PlaceDTO>> getAllPlaces() {
        logger.info("Received request to get all places");
        return placeservice.getAllPlaces();
    }

    @GetMapping("/getplacebyid/{placeId}")
    public ResponseEntity<PlaceDTO> getPlaceById(@PathVariable(name = "placeId") Integer placeId) throws Throwable {
        logger.info("Received request to get place by ID: {}", placeId);
        return placeservice.getPlaceById(placeId);
    }

    @GetMapping("/getplacebyname/{placeName}")
    public ResponseEntity<List<PlaceDTO>> getPlaceByName(@PathVariable(name = "placeName") String placeName)
            throws Throwable {
        logger.info("Received request to get place by name: {}", placeName);
        return placeservice.getPlaceByName(placeName);
    }

    @GetMapping("/getplacebytags/{tags}")
    public ResponseEntity<PlaceDTO> getPlaceByTags(@PathVariable(name = "tags") String tags) throws Throwable {
        logger.info("Received request to get place by tags: {}", tags);
        return placeservice.getPlaceByTags(tags);
    }

    @Valid
    @PutMapping("/updateplaces/")
    public ResponseEntity<String> updatePlaces(@RequestBody PlaceDTO placeDto) throws Throwable {
        logger.info("Received request to update place: {}", placeDto.getPlaceId());
        return placeservice.updatePlaces(placeDto);
    }

    @DeleteMapping("/deletePlaceByName/{placeName}")
    public ResponseEntity<String> deletePlaceByName(@PathVariable(name = "placeName") String placeName) throws Throwable {
        logger.info("Received request to delete place by name: {}", placeName);
        return placeservice.deletePlace(placeName);
    }

    @DeleteMapping("/deletePlaceById/{placeId}")
    public ResponseEntity<String> deletePlaceById(@PathVariable(name = "placeId") Integer placeId) throws Throwable {
        logger.info("Received request to delete place by ID: {}", placeId);
        return placeservice.deletePlaceById(placeId);
    }

    // client methods

    @GetMapping("/getplacefortour/{placeId}")
    public Integer getPlacefortour(@PathVariable(name = "placeId") Integer placeId) throws Throwable {
        logger.info("Received request to get place for tour by ID: {}", placeId);
        return placeservice.getPlacefortour(placeId);
    }

    @PostMapping("/getListOfPlacedtoById")
    public ResponseEntity<List<PlaceDTO>> getListOfPlaceDTOByPlaceId(@RequestBody List<Integer> placeIds)
            throws Throwable {
        logger.info("Received request to get list of placeDTOs by place IDs");
        return placeservice.getListOfPlaceDTOByPlaceId(placeIds);
    }

    // returns list of selected placeId's

    @Valid
    @PostMapping("/getListOfPlaceIds")
    public ResponseEntity<List<Integer>> getListOfPlaceIds(@RequestBody List<Integer> placeIds) throws Throwable {
        logger.info("Received request to get list of place IDs");
        return placeservice.getListOfPlaceIdsl(placeIds);
    }
}
