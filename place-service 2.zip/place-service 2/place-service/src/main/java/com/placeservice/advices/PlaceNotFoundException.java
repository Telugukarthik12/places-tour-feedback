package com.placeservice.advices;

public class PlaceNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public PlaceNotFoundException (String message){
		super(message);
	}
}
