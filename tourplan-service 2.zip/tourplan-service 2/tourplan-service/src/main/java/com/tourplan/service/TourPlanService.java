package com.tourplan.service;

import org.springframework.http.ResponseEntity;

import com.tourplan.dto.TourDetailsDTO;
import com.tourplan.dto.TourPlanResponseDTO;

public interface TourPlanService {

	ResponseEntity<String> updateTour(Integer tourId, TourDetailsDTO tourDetailsDto) throws Throwable;

	ResponseEntity<String> deleteTour(Integer tourId) throws Throwable;

	ResponseEntity<String> createPlan(Integer userId, TourDetailsDTO tourDetailsDto);

	ResponseEntity<TourPlanResponseDTO> getTourPlan(Integer tourId) throws Throwable;

}
