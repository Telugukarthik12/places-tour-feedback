package com.tourplan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tourplan.entity.Tour;

public interface TourRepository extends JpaRepository<Tour, Integer> {

}
