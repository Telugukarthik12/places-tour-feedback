package com.userservice.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userservice.dto.UserDTO;
import com.userservice.entity.User;
import com.userservice.repository.UserRepo;
import com.userservice.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Override
	public UserDTO registerUser(UserDTO userDTO) {

		User user = new User();

		user.setUserName(userDTO.getUserName());
		user.setUserEmail(userDTO.getUserEmail());
		user.setPassword(userDTO.getPassword());
		user.setNumber(userDTO.getNumber());
		user.setAddress(userDTO.getAddress());
		user.setRole(userDTO.getRole());
		userRepo.save(user);

		return userDTO;

	}

	public String signIn(String username, String password) {
		User user = userRepo.findByUserNameAndPassword(username, password);

		if (user != null) {
			return "Login Successfull";
		} else
			return "Sorry! Please check username and password";
	}

	public UserDTO findUserById(Integer userId) {
		Optional<User> userOptional = userRepo.findById(userId);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			UserDTO userDTO = new UserDTO();
			userDTO.setUserId(user.getUserId());
			userDTO.setUserName(user.getUserName());
			userDTO.setUserEmail(user.getUserEmail());
			userDTO.setPassword(user.getPassword());
			userDTO.setNumber(user.getNumber());
			userDTO.setAddress(user.getAddress());
			userDTO.setRole(user.getRole());
			return userDTO;
		} else {
			// Handle scenario when user is not found
			return null;
		}
	}

	public UserDTO updateUser(Integer userId, UserDTO userDTO) {
		Optional<User> optionalUser = userRepo.findById(userId);
		if (optionalUser.isPresent()) {
			User existingUser = optionalUser.get();
			existingUser.setUserName(userDTO.getUserName());
			existingUser.setUserEmail(userDTO.getUserEmail());
			existingUser.setPassword(userDTO.getPassword());
			existingUser.setNumber(userDTO.getNumber());
			existingUser.setAddress(userDTO.getAddress());
			existingUser.setRole(userDTO.getRole());
			userRepo.save(existingUser);
			return userDTO;
		} else {
			// Handle scenario when user to update is not found
			return null;
		}
	}

	public List<UserDTO> getAllUsers() {
		List<User> users = userRepo.findAll();
		List<UserDTO> userDTOs = new ArrayList<>();

		for (User user : users) {
			UserDTO userDTO = new UserDTO();
			userDTO.setUserId(user.getUserId());
			userDTO.setUserName(user.getUserName());
			userDTO.setUserEmail(user.getUserEmail());
			userDTO.setPassword(user.getPassword());
			userDTO.setNumber(user.getNumber());
			userDTO.setAddress(user.getAddress());
			userDTO.setRole(user.getRole());
			userDTOs.add(userDTO);
		}

		return userDTOs;
	}

	@Override
	public UserDTO findUserByName(String userName) {
		Optional<User> userOptional = userRepo.findByUserName(userName);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			UserDTO userDTO = new UserDTO();
			userDTO.setUserId(user.getUserId());
			userDTO.setUserName(user.getUserName());
//			userDTO.setUserEmail(user.getUserEmail());
			userDTO.setPassword(user.getPassword());
			userDTO.setNumber(user.getNumber());
			userDTO.setAddress(user.getAddress());
			userDTO.setRole(user.getRole());
			return userDTO;
		} else {
			// Handle scenario when user is not found
			return null;
		}
	}

	@Override
	public Integer getUserForClient(Integer userId) {
		User user = userRepo.findById(userId).get();
		Integer userId1 = user.getUserId();
		return userId1;
	}

	// create user
	// view user by id
	// view users
	// update user

}
